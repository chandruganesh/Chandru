package com.example.cab;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class DriverLogin  extends AppCompatActivity {
    EditText e1,e2;
    FirebaseAuth ma;
    ProgressDialog loading;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.driverlogin);
        e1=findViewById(R.id.e1);
        e2=findViewById(R.id.e2);
        Button b1=findViewById(R.id.b1);
        Button b2=findViewById(R.id.b2);
        ma=FirebaseAuth.getInstance();
        loading=new ProgressDialog(this);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=e1.getText().toString();
                String password=e2.getText().toString();
                driversign(email,password);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(DriverLogin.this,DriverRegister.class);
                startActivity(i);
            }
        });

    }

    private void driversign(String email, String password) {
        if(TextUtils.isEmpty(email))
        {
            e1.setError("Enter your Email Id");
        }
        if(TextUtils.isEmpty(password))
        {
            e2.setError("Enter your password");
        }
        else
        {
            loading.setTitle("Driver Login");
            loading.setMessage("Please wait, while we are checking your credentials...");
            loading.show();
            ma.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful())
                    {
                        Intent i=new Intent(DriverLogin.this,MapsActivity.class);
                        startActivity(i);
                        Toast.makeText(DriverLogin.this,"Driver login successful",Toast.LENGTH_LONG).show();
                        loading.dismiss();
                    }
                    else
                    {
                        Toast.makeText(DriverLogin.this,"Login failed",Toast.LENGTH_LONG).show();
                        loading.dismiss();
                    }
                }
            });
        }
    }
}
