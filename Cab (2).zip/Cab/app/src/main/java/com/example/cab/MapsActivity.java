package com.example.cab;

import android.Manifest;

import android.content.Intent;
import android.content.pm.PackageManager;

import android.location.Location;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        com.google.android.gms.location.LocationListener {
    GoogleApiClient mGoogleApiClient;
    Location mLastLocation;
    LocationRequest locationRequest;

    private GoogleMap mMap;

    private Button b1,b2;
    private FirebaseAuth mAuth;
    private FirebaseUser currentuser;
    private Boolean currentlogoutdriverstatus=false;
    private DatabaseReference assignedcustomerref, assinedcustomerpickupref;
    private String driverid,customerid="";
    Marker pickupmaker;
    private ValueEventListener assinedcustomerpickupreflistner;

    private TextView txtname,txtphone;
    private CircleImageView profilepic;
    private RelativeLayout relativeLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_maps);
        b1=findViewById(R.id.b1);
        b2=findViewById(R.id.b2);
        mAuth=FirebaseAuth.getInstance();
        currentuser=mAuth.getCurrentUser();
        driverid=mAuth.getCurrentUser().getUid();

        txtname=findViewById(R.id.name_customer);
        txtphone=findViewById(R.id.phone_customer);
        relativeLayout=findViewById(R.id.rell1);
        profilepic=findViewById(R.id.profile_image_customer);

        SupportMapFragment mapFragment = (SupportMapFragment)
                getSupportFragmentManager()
                        .findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MapsActivity.this,SettingActivity.class);
                i.putExtra("type","Drivers");
                startActivity(i);
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentlogoutdriverstatus=true;
                disconnecthedriver();
                mAuth.signOut();
                LogoutDriver();
            }
        });
        getassignedrequest();
    }

    private void getassignedrequest() {
        assignedcustomerref=FirebaseDatabase.getInstance().getReference().child("users")
                .child("Drivers").child(driverid).child("CustomerRideID");
        assignedcustomerref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists())
                {
                    customerid=snapshot.getValue().toString();
                    getassignedcustomerpickuplocation();


                    relativeLayout.setVisibility(View.VISIBLE);
                    getassignedcustomerinfo();
                }
                else
                {
                    customerid="";
                    if(pickupmaker!=null)
                    {
                        pickupmaker.remove();
                    }
                    if(assinedcustomerpickupreflistner!=null)
                    {
                        assinedcustomerpickupref.removeEventListener(assinedcustomerpickupreflistner);
                    }
                    relativeLayout.setVisibility(View.GONE);

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    private void getassignedcustomerpickuplocation() {
        assinedcustomerpickupref=FirebaseDatabase.getInstance().getReference().child("Customer requests")
                .child(customerid).child("l");
        assinedcustomerpickupreflistner=assinedcustomerpickupref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists())
                {
                    List<Object> customerlocationmap=(List<Object>) snapshot.getValue();
                    double locatiolat=0;
                    double locationlog=0;
                    if(customerlocationmap.get(0)!=null)
                    {
                        locatiolat=Double.parseDouble(customerlocationmap.get(0).toString());
                    }
                    if(customerlocationmap.get(1)!=null)
                    {
                        locationlog=Double.parseDouble(customerlocationmap.get(1).toString());
                    }
                    LatLng driverlatlog=new LatLng(locatiolat,locationlog);
                    pickupmaker=mMap.addMarker(new MarkerOptions().position(driverlatlog).title("Customer pickup location").icon(BitmapDescriptorFactory.fromResource(R.drawable.user)));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        buildGoogleApiClient();
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        mMap.setMyLocationEnabled(true);
    }
    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();
    }
    @Override
    public void onConnected(Bundle bundle) {
        locationRequest = new LocationRequest();
        locationRequest.setInterval(1000);
        locationRequest.setFastestInterval(1000);
        locationRequest.setPriority(locationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient,
                    locationRequest, this);
        }
    }
    @Override
    public void onConnectionSuspended(int i) {
    }
    @Override
    public void onLocationChanged(Location location) {
        if(getApplicationContext()!=null)
        {
            mLastLocation = location;
            LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
            mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
            mMap.animateCamera(CameraUpdateFactory.zoomTo(13));
            String urerid= FirebaseAuth.getInstance().getCurrentUser().getUid();
            DatabaseReference Driveravailabilityref= FirebaseDatabase.getInstance().getReference().child("Drivers Available");
            GeoFire geoFire=new GeoFire(Driveravailabilityref);

            DatabaseReference driverworkingref=FirebaseDatabase.getInstance().getReference().child("Drivers working");
            GeoFire geoFireworking=new GeoFire(driverworkingref);
           switch (customerid)
           {
               case "":
                   geoFireworking.removeLocation(urerid);
                   geoFire.setLocation(urerid,new GeoLocation(location.getLatitude(),location.getLongitude()));
                   break;
               default:
                   geoFire.removeLocation(urerid);
                   geoFireworking.setLocation(urerid,new GeoLocation(location.getLatitude(),location.getLongitude()));
                   break;
           }
        }
    }


    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
    @Override
    protected void onStop() {
        super.onStop();
       if(!currentlogoutdriverstatus){
           disconnecthedriver();
       }
    }

    private void disconnecthedriver() {
        String urerid= FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference Driveravailabilityref= FirebaseDatabase.getInstance().getReference().child("Drivers Available");

        GeoFire geoFire=new GeoFire(Driveravailabilityref);
        geoFire.removeLocation(urerid);
    }
    private void LogoutDriver() {
        Intent i=new Intent(MapsActivity.this,MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }
    private void getassignedcustomerinfo()
    {
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference().child("users").child("customers").child(customerid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists() && snapshot.getChildrenCount()>0)
                {
                    String name1=snapshot.child("name").getValue().toString();

                    String number1=snapshot.child("phone").getValue().toString();

                    txtname.setText(name1);
                    txtphone.setText(number1);

                    if(snapshot.hasChild("image"))
                    {
                        String image=snapshot.child("image").getValue().toString();
                        Picasso.get().load(image).into(profilepic);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


}