package com.example.cab;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;

import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

public class SettingActivity extends AppCompatActivity {
    private CircleImageView profileimageview;
    private EditText name,number,car_name;
    private TextView change_picture;
    private ImageView save,close;
    private String type;
    private String checker="";
    private Uri imageuri;
    private String myuri="";
    private StorageTask uploadtask;
    private StorageReference storageprofilepicref;
    private DatabaseReference databaseReference;
    private FirebaseAuth mauth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        type=getIntent().getStringExtra("type");
        Toast.makeText(SettingActivity.this,type,Toast.LENGTH_LONG).show();

        mauth=FirebaseAuth.getInstance();
        databaseReference= FirebaseDatabase.getInstance().getReference().child("users").child(type);
        storageprofilepicref= FirebaseStorage.getInstance().getReference().child("Profile pictures");


        profileimageview=findViewById(R.id.profile_image);
        name=findViewById(R.id.name);
        number=findViewById(R.id.phone_number);
        car_name=findViewById(R.id.car_name);
        if(type.equals("Drivers"))
        {
            car_name.setVisibility(View.VISIBLE);
        }
        change_picture=findViewById(R.id.change_picture);
        save=findViewById(R.id.save_button);
        close=findViewById(R.id.close_button);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(type.equals("Drivers"))
                {
                    Intent i=new Intent(SettingActivity.this,MapsActivity.class);
                    startActivity(i);
                }
                else
                {
                    Intent i=new Intent(SettingActivity.this,CustomerMapsActivity.class);
                    startActivity(i);
                }
            }
        });
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checker.equals("clicked"))
                {
                    profileval();
                }
                else
                {
                    validateandsaveonlyinformation();
                }
            }
        });
        change_picture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checker="clicked";
                CropImage.activity().setAspectRatio(1,1).start(SettingActivity.this);
            }
        });
        getuserinfo();
    }

    private void validateandsaveonlyinformation() {
        if (TextUtils.isEmpty(name.getText().toString())) {
            name.setError("Enter your name");
        }
        else if (TextUtils.isEmpty(number.getText().toString())) {
            number.setError("Enter your phone number");
        }
        else if(type.equals("Drivers") && TextUtils.isEmpty(car_name.getText().toString())) {
            number.setError("Enter your car name");
        }
        else
        {
            HashMap<String,Object> usremap=new HashMap<>();
            usremap.put("uid",mauth.getCurrentUser().getUid());
            usremap.put("name",name.getText().toString());
            usremap.put("phone",number.getText().toString());
            if(type.equals("Drivers"))
            {
                usremap.put("car",car_name.getText().toString());
            }
            databaseReference.child(mauth.getCurrentUser().getUid()).updateChildren(usremap);
            if(type.equals("Drivers"))
            {
                startActivity(new Intent(SettingActivity.this,MapsActivity.class));
            }
            else
            {
                startActivity(new Intent(SettingActivity.this,CustomerMapsActivity.class));
            }
        }
    }

    private void getuserinfo()
    {
        databaseReference.child(mauth.getCurrentUser().getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()&& snapshot.getChildrenCount()>0)
                {
                    String name1=snapshot.child("name").getValue().toString();

                    String number1=snapshot.child("phone").getValue().toString();
                    name.setText(name1);
                    number.setText(number1);
                    if(type.equals("Drivers"))
                    {
                        String car=snapshot.child("car").getValue().toString();
                        car_name.setText(car);
                    }
                    if(snapshot.hasChild("image"))
                    {
                        String image=snapshot.child("image").getValue().toString();
                        Picasso.get().load(image).into(profileimageview);
                    }


                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void profileval () {
        if (TextUtils.isEmpty(name.getText().toString())) {
            name.setError("Enter your name");
        }
        else if (TextUtils.isEmpty(number.getText().toString())) {
            number.setError("Enter your phone number");
        }
        else if(type.equals("Drivers") && TextUtils.isEmpty(car_name.getText().toString())) {
            number.setError("Enter your car name");
        }
        else if(checker.equals("clicked"))
        {
            uploadprofilepic();
        }
    }

    private void uploadprofilepic() {
        final ProgressDialog progressDialog=new ProgressDialog(this);
        progressDialog.setTitle("Setting account information");
        progressDialog.setMessage("Please wait, while we are updating your account information");
        progressDialog.show();


        if(imageuri!=null)
        {
            final StorageReference fileref=storageprofilepicref.child(mauth.getCurrentUser().getUid() + ".jpg");
            uploadtask=fileref.putFile(imageuri);
            uploadtask.continueWithTask(new Continuation() {
                @Override
                public Object then(@NonNull Task task) throws Exception {
                    if(!task.isSuccessful())
                    {
                        throw task.getException();
                    }
                    return fileref.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if(task.isSuccessful())
                    {
                        Uri downloaduri=task.getResult();
                        myuri=downloaduri.toString();


                        HashMap<String,Object> usremap=new HashMap<>();
                        usremap.put("uid",mauth.getCurrentUser().getUid());
                        usremap.put("name",name.getText().toString());
                        usremap.put("phone",number.getText().toString());
                        usremap.put("image",myuri);
                        if(type.equals("Drivers"))
                        {
                            usremap.put("car",car_name.getText().toString());
                        }
                        databaseReference.child(mauth.getCurrentUser().getUid()).updateChildren(usremap);
                        progressDialog.dismiss();
                        if(type.equals("Drivers"))
                        {
                            startActivity(new Intent(SettingActivity.this,MapsActivity.class));
                        }
                        else
                        {
                            startActivity(new Intent(SettingActivity.this,CustomerMapsActivity.class));
                        }
                    }
                }
            });
        }
        else
        {
            Toast.makeText(this,"Image not selected",Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE && resultCode==RESULT_OK && data!=null)
        {
            CropImage.ActivityResult result= CropImage.getActivityResult(data);
            imageuri=result.getUri();
            profileimageview.setImageURI(imageuri);
        }
        else
        {
            if(type.equals("Drivers"))
            {
                startActivity(new Intent(SettingActivity.this,MapsActivity.class));
            }
            else
            {
                startActivity(new Intent(SettingActivity.this,CustomerMapsActivity.class));
            }

            Toast.makeText(this,"Error, try again",Toast.LENGTH_LONG).show();
        }
    }
}