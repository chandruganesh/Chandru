package com.example.cab;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.firebase.geofire.GeoQuery;
import com.firebase.geofire.GeoQueryEventListener;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.security.Key;
import java.util.HashMap;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class CustomerMapsActivity extends FragmentActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        com.google.android.gms.location.LocationListener {
    GoogleApiClient mGoogleApiClient;
    Location lastLocation;
    LocationRequest locationRequest;

    private GoogleMap mMap;
    private Button b1, b2, b3;
    private FirebaseAuth mAuth;
    private FirebaseUser currentuser;
    private String customerid;

    private DatabaseReference databaseReferencecustomer;

    private LatLng customerpickuplocation;
    private Boolean currentlogoutcustomerstatus = false;
    private Boolean driverfound=false,requessttype=false;
    private DatabaseReference driveravailableref;
    private String driverfoundid;
    private int radius = 1;
    private DatabaseReference driverref;
    private DatabaseReference driverlocationref;
    Marker drivermarker, pickupmaker;
    private ValueEventListener driverlocationreflistner;
    GeoQuery geoQuery;

    private TextView txtname,txtphone,txtcarname;
    private CircleImageView profilepic;
    private RelativeLayout relativeLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cactivity_customer_maps);
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        mAuth = FirebaseAuth.getInstance();
        currentuser = mAuth.getCurrentUser();
        databaseReferencecustomer = FirebaseDatabase.getInstance().getReference().child("Customer requests");
        driveravailableref = FirebaseDatabase.getInstance().getReference().child("Drivers Available");
        driverlocationref=FirebaseDatabase.getInstance().getReference().child("Drivers working");

        txtname=findViewById(R.id.name_driver);
        txtphone=findViewById(R.id.phone_driver);
        txtcarname=findViewById(R.id.car_name_driver);
        relativeLayout=findViewById(R.id.rell);
        profilepic=findViewById(R.id.profile_image);



        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(CustomerMapsActivity.this,SettingActivity.class);
                i.putExtra("type","customers");
                startActivity(i);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentlogoutcustomerstatus = true;
                disconnecthecustomer();
                mAuth.signOut();
                Logoutcustomer();

            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(requessttype)
                {
                    requessttype=false;
                    geoQuery.removeAllListeners();
                    driverlocationref.removeEventListener(driverlocationreflistner);
                    if(driverfound!=null)
                    {
                        driverref=FirebaseDatabase.getInstance().getReference()
                                .child("users").child("Drivers").child(driverfoundid).child("CustomerRideID");
                        driverref.removeValue();
                        driverfoundid=null;
                    }
                    driverfound=false;
                    radius=1;
                    customerid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                    GeoFire geoFire = new GeoFire(databaseReferencecustomer);
                    geoFire.setLocation(customerid, new GeoLocation(lastLocation.getLatitude(), lastLocation.getLongitude()));
                    geoFire.removeLocation(customerid);

                    if(pickupmaker!=null)
                    {
                        pickupmaker.remove();
                    }
                    if(drivermarker!=null)
                    {
                        drivermarker.remove();
                    }
                    b3.setText("Call a cab");
                    relativeLayout.setVisibility(View.GONE);

                }
                else
                {
                    requessttype=true;
                    customerid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                    GeoFire geoFire = new GeoFire(databaseReferencecustomer);
                    geoFire.setLocation(customerid, new GeoLocation(lastLocation.getLatitude(), lastLocation.getLongitude()));
                    customerpickuplocation = new LatLng(lastLocation.getLatitude(), lastLocation.getLongitude());
                    pickupmaker=mMap.addMarker(new MarkerOptions().position(customerpickuplocation).title("My location").icon(BitmapDescriptorFactory.fromResource(R.drawable.user)));
                    b3.setText("Getting your driver...");
                    getclosestdriver();
                }
            }
        });
    }
    private void getclosestdriver() {
        GeoFire geoFire = new GeoFire(driveravailableref);
        geoQuery = geoFire.queryAtLocation(new GeoLocation(customerpickuplocation.latitude, customerpickuplocation.longitude), radius);
        geoQuery.removeAllListeners();
        geoQuery.addGeoQueryEventListener(new GeoQueryEventListener() {
            @Override
            public void onKeyEntered(String key, GeoLocation location) {
                if(!driverfound && requessttype)
                {
                    driverfound=true;
                    driverfoundid= key;
                    driverref=FirebaseDatabase.getInstance().getReference().child("users").child("Drivers").child(driverfoundid);
                    HashMap driverhashMap=new HashMap();
                    driverhashMap.put("CustomerRideID",customerid);
                    driverref.updateChildren(driverhashMap);
                    b3.setText("Looking for driver location");
                    gettingdriverlocation();

                }

            }

            @Override
            public void onKeyExited(String key) {


            }

            @Override
            public void onKeyMoved(String key, GeoLocation location) {

            }

            @Override
            public void onGeoQueryReady() {
                if(!driverfound)
                {
                    radius=radius+1;
                    getclosestdriver();
                }

            }

            @Override
            public void onGeoQueryError(DatabaseError error) {

            }
        });
    }

    private void gettingdriverlocation() {
       driverlocationreflistner= driverlocationref.child(driverfoundid).child("l").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists() && requessttype)
                {
                    List<Object> driverlocationmap=(List<Object>) snapshot.getValue();
                    double locatiolat=0;
                    double locationlog=0;
                    b3.setText("Drivers found");

                    relativeLayout.setVisibility(View.VISIBLE);
                    getassigneddriverinfo();
                    if(driverlocationmap.get(0)!=null)
                    {
                        locatiolat=Double.parseDouble(driverlocationmap.get(0).toString());
                    }
                    if(driverlocationmap.get(1)!=null)
                    {
                        locationlog=Double.parseDouble(driverlocationmap.get(1).toString());
                    }
                    LatLng driverlatlog=new LatLng(locatiolat,locationlog);
                    if(drivermarker!=null)
                    {
                        drivermarker.remove();
                    }
                    Location location1=new Location("");
                    location1.setLatitude(customerpickuplocation.latitude);
                    location1.setLongitude(customerpickuplocation.longitude);

                    Location location2=new Location("");
                    location2.setLatitude(driverlatlog.latitude);
                    location2.setLongitude(driverlatlog.longitude);
                    float distance=location1.distanceTo(location2);
                    if(distance<10)
                    {
                        b3.setText("Driver arrived");
                    }
                    else
                    {
                        b3.setText("Driver found"+ String.valueOf(distance));
                    }
                    drivermarker=mMap.addMarker(new MarkerOptions().position(driverlatlog).title("Your driver is here").icon(BitmapDescriptorFactory.fromResource(R.drawable.car)));

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        buildGoogleApiClient();
        mMap.setMyLocationEnabled(true);
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        locationRequest = new LocationRequest();
        locationRequest.setInterval(1000);
        locationRequest.setFastestInterval(1000);
        locationRequest.setPriority(locationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient,
                    locationRequest, this);
        }

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        lastLocation = location;
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(14));

    }

    protected synchronized void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();
    }

    private void disconnecthecustomer() {
        String urerid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference Driveravailabilityref = FirebaseDatabase.getInstance().getReference().child("Drivers available");

        GeoFire geoFire = new GeoFire(Driveravailabilityref);
        geoFire.removeLocation(urerid);
    }

    private void Logoutcustomer() {
        Intent i = new Intent(CustomerMapsActivity.this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
        finish();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (!currentlogoutcustomerstatus) {
            disconnecthecustomer();
        }
    }

    private void getassigneddriverinfo()
    {
        DatabaseReference reference=FirebaseDatabase.getInstance().getReference().child("users").child("Drivers").child(driverfoundid);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists() && snapshot.getChildrenCount()>0)
                {
                    String name1=snapshot.child("name").getValue().toString();

                    String number1=snapshot.child("phone").getValue().toString();
                    String car=snapshot.child("car").getValue().toString();

                    txtname.setText(name1);
                    txtphone.setText(number1);
                    txtcarname.setText(car);

                    if(snapshot.hasChild("image"))
                    {
                        String image=snapshot.child("image").getValue().toString();
                        Picasso.get().load(image).into(profilepic);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}